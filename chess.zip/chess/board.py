import tkinter as tk
import copy
from PIL import Image, ImageTk

class ChessBoard:



    def __init__(self):
        # Initialize an 8x8 chessboard
        self.board = [[' ' for _ in range(8)] for _ in range(8)]
        self.initialize_board()
        self.is_white_turn = True

    def initialize_board(self):
        # Initialize the chessboard with starting positions of pieces
        
        # Starting positions for black pieces
        self.board[0][0] = 'black_rook'  # Queen's Rook
        self.board[0][1] = 'black_knight'  # Queen's Knight
        self.board[0][2] = 'black_bishop'  # Queen's Bishop
        self.board[0][3] = 'black_queen'   # Queen
        self.board[0][4] = 'black_king'   # King
        self.board[0][5] = 'black_bishop'  # King's Bishop
        self.board[0][6] = 'black_knight'  # King's Knight
        self.board[0][7] = 'black_rook'  # King's Rook
        for i in range(8):
            self.board[1][i] = 'black_pawn'  # Pawn

        # Starting positions for white pieces
        self.board[7][0] = 'white_rook'  # Queen's Rook
        self.board[7][1] = 'white_knight'  # Queen's Knight
        self.board[7][2] = 'white_bishop'  # Queen's Bishop
        self.board[7][3] = 'white_queen'   # Queen
        self.board[7][4] = 'white_king'   # King
        self.board[7][5] = 'white_bishop'  # King's Bishop
        self.board[7][6] = 'white_knight'  # King's Knight
        self.board[7][7] = 'white_rook'  # King's Rook
        for i in range(8):
            self.board[6][i] = 'white_pawn'  # Pawn

    def make_move(self, move):
        # Make a move on the chessboard
        from_x, from_y, to_x, to_y = move
        piece = self.board[from_x][from_y]  # Get the piece to be moved
        self.board[from_x][from_y] = ' '  # Clear the source position
        self.board[to_x][to_y] = piece  # Place the piece at the destination position

    def is_move_legal(self, move, is_white_turn):
        from_x, from_y, to_x, to_y = move
        piece = self.board[from_x][from_y]
        target_piece = self.board[to_x][to_y]

        # Check if the source position is within the board and contains a piece
        if not (0 <= from_x < 8) or not (0 <= from_y < 8) or piece == ' ':
            return False

        # Check if the destination position is within the board
        if not (0 <= to_x < 8) or not (0 <= to_y < 8):
            return False

        # Check if the destination position is not occupied by a friendly piece
        if target_piece[0] == piece[0]:
            return False

        # Implement rules specific to each type of chess piece (e.g., pawn, knight, etc.)
        if piece == 'black_rook' or piece == 'white_rook':
            if not self.is_rook_move_legal(move):
                return False
            
        if piece == 'black_bishop' or piece == 'white_bishop':
            if not self.is_bishop_move_legal(move):
                return False
            
        if piece == 'black_knight' or piece == 'white_knight':
            if not self.is_knight_move_legal(move):
                return False
            
        if piece == 'black_king' or piece == 'white_king':
            if not self.is_king_move_legal(move):
                return False
            
        if piece == 'white_queen' or piece == 'black_queen':
            if not self.is_bishop_move_legal(move) and not self.is_rook_move_legal(move):
                return False
            
        if piece == 'white_pawn' or piece == 'black_pawn':
            if not self.is_pawn_move_legal(move):
                return False
             
        if is_white_turn:

            board_copy = self.copy_board()
            
            board_copy.make_move(move)     

            bruh = 0
            king_x, king_y = board_copy.find_king_position(is_white_turn)
            if (king_x == None or king_y == None):
                #print('problem: ', king_x, ' ', king_y, ' ', is_white_turn)
                return False
            if board_copy.is_square_attacked(king_x,king_y,is_white_turn):
                for i in range(8):
                    for j in range(8):
                        if self.board[i][j] != board_copy.board[i][j]:
                            print(f"({i}, {j}): {self.board[i][j]} -> {board_copy.board[i][j]}")
                            bruh = bruh + 1
                return False


        # Return True if the move is legal based on the piece-specific rules
        return True
    
    def is_rook_move_legal(self, move):
        # Check if the rook's move is legal (vertical or horizontal)

        from_x, from_y, to_x, to_y = move

        if from_x != to_x and from_y != to_y:
            return False

        # Check for any pieces blocking the path
        if from_x == to_x:  # Moving vertically
            step = 1 if from_y < to_y else -1
            y = from_y + step
            while y != to_y:
                if not (0 <= y < 8) or self.board[from_x][y] != ' ':
                    return False
                y += step
        else:  # Moving horizontally
            step = 1 if from_x < to_x else -1
            x = from_x + step
            while x != to_x:
                if not (0 <= x < 8) or self.board[x][from_y] != ' ':
                    return False
                x += step

        return True
   
    def is_bishop_move_legal(self, move):
        # Check if the bishop's move is legal (diagonal)

        from_x, from_y, to_x, to_y = move

        if abs(from_x - to_x) != abs(from_y - to_y):
            return False

        # Check for any pieces blocking the path
        x_step = 1 if to_x > from_x else -1
        y_step = 1 if to_y > from_y else -1
        x, y = from_x + x_step, from_y + y_step
        while (x, y) != (to_x, to_y):
            if not (0 <= x < 8) or not (0 <= y < 8) or self.board[x][y] != ' ':
                return False
            x += x_step
            y += y_step

        return True
    
    def is_knight_move_legal(self, move):
        # Check if the move follows the L-shape pattern of a knight

        from_x, from_y, to_x, to_y = move

        dx = abs(to_x - from_x)
        dy = abs(to_y - from_y)
        return (dx == 1 and dy == 2) or (dx == 2 and dy == 1)
    
    def is_king_move_legal(self, move):
        # Check if the king's move is legal (one square in any direction)

        from_x, from_y, to_x, to_y = move

        x_diff = abs(from_x - to_x)
        y_diff = abs(from_y - to_y)
        return x_diff <= 1 and y_diff <= 1
    
    def is_pawn_move_legal(self, move):
        # Check if the pawn's move is legal

        from_x, from_y, to_x, to_y = move

        piece = self.board[from_x][from_y]
        if piece == 'white_pawn':
            is_white = True
        else:
            is_white = False
        x_diff = abs(from_x - to_x)
        y_diff = abs(from_y - to_y)

        if is_white:
            # White pawn can move one square forward
            if from_x - to_x == 1 and y_diff == 0 and self.board[to_x][to_y] == ' ':
                return True
            # White pawn can move two squares forward from starting position
            if from_x == 6 and from_x - to_x == 2 and y_diff == 0 and self.board[to_x][to_y] == ' ' and self.board[to_x+1][to_y] == ' ':
                return True
            # White pawn can capture diagonally
            if from_x - to_x == 1 and y_diff == 1 and self.board[to_x][to_y][0] == 'b':
                return True
        else:
            # Black pawn can move one square forward
            if to_x - from_x == 1 and y_diff == 0 and self.board[to_x][to_y] == ' ':
                return True
            # Black pawn can move two squares forward from starting position
            if from_x == 1 and to_x - from_x == 2 and y_diff == 0 and self.board[to_x][to_y] == ' ' and self.board[to_x-1][to_y] == ' ':
                return True
            # Black pawn can capture diagonally
            if to_x - from_x == 1 and y_diff == 1 and self.board[to_x][to_y][0] == 'w':
                return True

        return False

    def get_legal_moves(self,is_white_turn=True):
        legal_moves = []

        # Iterate over the 8x8 chessboard.
        for from_x in range(8):
            for from_y in range(8):
                piece = self.board[from_x][from_y]
                if (is_white_turn == True and piece[0] == 'w') or (is_white_turn == False and piece[0] == 'b'):
                    for to_x in range(8):
                        for to_y in range(8):
                            move = (from_x, from_y, to_x, to_y)
                            if self.is_move_legal(move,is_white_turn):
                                legal_moves.append(move)

        return legal_moves

    def is_square_attacked(self, x, y, is_white_turn):
        # Check if the square at position (x, y) is attacked by any of the opponent's pieces

        # Define the opponent's pieces based on the current player's turn
        opponent_pieces = [
            'black_rook', 'black_knight', 
            'black_bishop', 'black_queen', 
            'black_king', 'black_pawn'
            ] if is_white_turn else [
            'white_rook', 'white_knight', 
            'white_bishop', 'white_queen', 
            'white_king', 'white_pawn'
            ]

        # Check if the square is attacked by any of the opponent's pieces
        for i in range(8):
            for j in range(8):
                piece = self.board[i][j]
                if piece in opponent_pieces:
                    # Check if the opponent's piece can legally move to the target square (x, y)
                    move = (i, j, x, y)
                    if self.is_move_legal(move,is_white_turn):
                        print('(is square attacked)',move,is_white_turn)
                        return True

        return False

    def find_king_position(self, is_white_turn):
        # Find the position of the king based on the current player's turn
        king = 'white_king' if is_white_turn else 'black_king'
        king_x, king_y = None, None

        # Iterate through the board to find the king's position
        for x in range(8):
            for y in range(8):
                if self.board[x][y] == king:
                    king_x, king_y = x, y
                    break    

#        if king_x == None or king_y == None:
#            print('starttttttttttttttttttttttttttt')
#            for x in range(8):
#                for y in range(8):
#
#                    print(self.board[x][y])
#
#            print('enddddddddddddddddddddddddddddd')

        return king_x, king_y
   
    def copy_board(self):
        # Create a deep copy of the current chessboard
        copied_board = copy.deepcopy(self)

        return copied_board

    def is_checkmate(self, is_white_turn):
        # Check if the king is in check
        king_x, king_y = self.find_king_position(is_white_turn)

        if (king_x == None or king_y == None):
            return True

        if self.is_square_attacked(king_x, king_y, is_white_turn):
            # The king is in check
            # Check if there are any legal moves for the player to get out of check
            legal_moves = self.get_legal_moves(is_white_turn)
            for move in legal_moves:
                # Simulate the move and check if the king is still in check
                board_copy = self.copy_board()
                board_copy.make_move(move)
                new_king_x, new_king_y = board_copy.find_king_position(is_white_turn)
                if not board_copy.is_square_attacked(new_king_x, new_king_y, is_white_turn):
                    # There is a legal move to get out of check
                    return False
            # If there are no legal moves to get out of check, it's checkmate
            return True
        # If the king is not in check, it's not checkmate
        return False

    def is_stalemate(self, is_white_turn):
        # Check if the current player is in a stalemate position

        # Find the position of the king
        king_x, king_y = self.find_king_position(is_white_turn)

        if (king_x == None or king_y == None):
            return True

        # Check if the king is in check
        if self.is_square_attacked(king_x, king_y, is_white_turn):
            return False  # The player is not in stalemate if their king is in check

        # Check if there are any legal moves for the player
        legal_moves = self.get_legal_moves(is_white_turn)

        for move in legal_moves:
            # Simulate the move
            board_copy = self.copy_board()
            board_copy.make_move(move)
            
            # Find the new position of the king after the move
            new_king_x, new_king_y = board_copy.find_king_position(is_white_turn)
            
            # Check if the new position of the king is not in check
            if not board_copy.is_square_attacked(new_king_x, new_king_y, is_white_turn):
                return False  # The player has at least one legal move that doesn't result in check

        # If no legal moves can be made without putting the king in check, it's a stalemate
        return True

    def evaluate_board(self):
        """
        Evaluate the current chessboard position.
        Positive values indicate an advantage for white, and negative values indicate an advantage for black.
        """
        evaluation = 0

        # Define piece values
        piece_values = {
            'black_pawn': -10,  # Black Pawn
            'black_queen': -90,  # Black Queen
            'black_king': -900,  # Black King (arbitrarily high value to prioritize king safety)
            'black_rook': -50,  # Black Rook
            'black_knight': -30,  # Black Knight
            'black_bishop': -30,  # Black Bishop
            'white_pawn': 10,   # White Pawn
            'white_queen': 90,   # White Queen
            'white_king': 900,  # White King (arbitrarily high value to prioritize king safety)
            'white_rook': 50,   # White Rook
            'white_knight': 30,   # White Knight
            'white_bishop': 30    # White Bishop
        }

        for row in self.board:
            for piece in row:
                evaluation += piece_values.get(piece, 0)

        return evaluation

chessboard = ChessBoard()

class ChessAI:

    def __init__(self, max_depth=1):
        self.max_depth = max_depth

    def minimax(self, board, depth, alpha, beta, is_maximizing_player,is_white_turn):
        if depth == 0 or board.is_checkmate(is_maximizing_player) or board.is_stalemate(is_maximizing_player):
            return board.evaluate_board()

        legal_moves = board.get_legal_moves(is_white_turn)

        if is_maximizing_player:
            max_eval = float('-inf')
            for move in legal_moves:
                board_copy = board.copy_board()
                board_copy.make_move(move)
                eval = self.minimax(board_copy, depth - 1, alpha, beta, False)  # Corrected to pass False here
                max_eval = max(max_eval, eval)
                alpha = max(alpha, eval)
                if beta <= alpha:
                    break
            return max_eval
        else:
            min_eval = float('inf')
            for move in legal_moves:
                board_copy = board.copy_board()
                board_copy.make_move(move)
                eval = self.minimax(board_copy, depth - 1, alpha, beta, True,is_white_turn)  # Corrected to pass True here
                min_eval = min(min_eval, eval)
                beta = min(beta, eval)
                if beta <= alpha:
                    break
            return min_eval

    def find_best_move(self, board,is_white_turn):
        legal_moves = board.get_legal_moves(is_white_turn)
        best_move = None
        best_eval = float('-inf')

        for move in legal_moves:
            board_copy = board.copy_board()
            board_copy.make_move(move)
            eval = self.minimax(board_copy, self.max_depth, float('-inf'), float('inf'), False,is_white_turn)
            if eval > best_eval:
                best_eval = eval
                best_move = move

        return best_move

class ChessBoardGUI:

    def __init__(self, root, chessboard):
        self.root = root
        self.root.title("Chessboard")
        self.chessboard = chessboard  # Store the chessboard instance
        self.canvas = tk.Canvas(root, width=400, height=400)
        self.canvas.pack()
        self.canvas.bind("<Button-1>", self.handle_click)  # Bind click event
        self.piece_images = self.load_piece_images()  # Load chess piece images
        self.draw_board()
        self.selected_piece = None
        self.selected_position = None
        self.ai_player = ChessAI()
        self.ai_turn_flag = False  # Initialize a flag to control AI's turn

    def load_piece_images(self):
        piece_images = {}

        # Load image files for each piece
        for color in ['white', 'black']:
            for piece in ['pawn', 'rook', 'knight', 'bishop', 'queen', 'king']:
                image = Image.open(f'images/{color}_{piece}.png')  # Replace with your image file paths
                image = image.resize((50, 50))  # Adjust the size as needed
                piece_images[f'{color}_{piece}'] = ImageTk.PhotoImage(image)

        return piece_images

    def highlight_legal_moves(self, row, col):
        legal_moves = self.chessboard.get_legal_moves()
        for move in legal_moves:
            from_x, from_y, to_x, to_y = move
            if from_x == row and from_y == col:
                x1, y1 = from_y * 50, from_x * 50
                x2, y2 = to_y * 50 + 50, to_x * 50 + 50
                self.canvas.create_rectangle(x1, y1, x2, y2, outline="red", width=3)

    def clear_legal_move_highlights(self):
        self.canvas.delete("highlighted_moves")

    def draw_board(self):
        square_size = 50

        for row in range(8):
            for col in range(8):
                x1, y1 = col * square_size, row * square_size
                x2, y2 = x1 + square_size, y1 + square_size
                # Alternate between light grey and light green
                if (row + col) % 2 == 0:
                    square_color = "#D3D3D3"  # Light grey
                else:
                    square_color = "#98FB98"  # Light green

                self.canvas.create_rectangle(x1, y1, x2, y2, fill=square_color)

                piece = self.chessboard.board[row][col]  # Get piece from the chessboard
                if piece != ' ':
                    piece_image = self.piece_images[piece]  # Get the image for the piece
                    self.canvas.create_image(x1, y1, anchor=tk.NW, image=piece_image)

    def handle_click(self, event):
        if not self.ai_turn_flag:
            x, y = event.x, event.y
            square_size = 50
            col = x // square_size
            row = y // square_size

            # Check if there's a piece at the clicked square
            piece = self.chessboard.board[row][col]

            if self.selected_piece is None:
                print('generating from...')
                # If no piece is currently selected, check if the clicked square contains a valid piece to move
                if piece != ' ':
                    # Store the selected piece and its position
                    self.selected_piece = (row, col)  # Store it as a tuple
                    self.highlight_legal_moves(row, col)  # Highlight legal moves for the selected piece
                    #print('piece: ',self.chessboard.board[row][col])
            elif self.selected_position is None:
                print('generating to...')

                to_x, to_y = row, col

                # Update selected_position
                self.selected_position = (to_x, to_y)

                self.canvas.delete("highlight")  # Clear the highlights
                self.draw_board()  # Redraw the board to remove highlights

        print('situation: ',self.selected_piece,self.selected_position)
            
    def ai_turn(self,is_white_turn):
        # AI's move calculation
        best_move = self.ai_player.find_best_move(self.chessboard,is_white_turn)

        # Make AI's move on the chessboard
        self.chessboard.make_move(best_move)

        # Update the GUI to reflect AI's move
        self.draw_board()

        # Check for checkmate or stalemate here, and handle game end conditions if needed 
        if self.chessboard.is_checkmate(self.chessboard.is_white_turn):
            print("AI is in checkmate!")
        elif self.chessboard.is_stalemate(self.chessboard.is_white_turn):
            print("Stalemate!")

        # Reset the AI's turn flag
        self.ai_turn_flag = False
        # Return control to the player for their next move

def main():
    # Create a Tkinter root window
    root = tk.Tk()
    root.title("Chessboard")

    # Create a ChessBoardGUI instance with the root window and ChessBoard
    chessboard_gui = ChessBoardGUI(root, chessboard)

    player_turn = True  # Initialize as player's turn

    while not chessboard.is_checkmate(player_turn) and not chessboard.is_stalemate(player_turn):
        if player_turn:
            root.update()  # Update the GUI to handle player's clicks
            
            # Player has made a move
            if chessboard_gui.selected_position is not None and chessboard_gui.selected_piece is not None:
                from_x, from_y = chessboard_gui.selected_piece  # Get source position
                to_x, to_y = chessboard_gui.selected_position  # Get destination position

                # Ensure chessboard_gui.selected_piece is a tuple (to_x, to_y)
                if isinstance(chessboard_gui.selected_piece, tuple) and isinstance(chessboard_gui.selected_piece,tuple):
                    move = (from_x, from_y, to_x, to_y)
                    king_x,king_y = chessboard.find_king_position(True)
                    print('king: ',king_x,king_y)
                    print('move: ',move)
                    print('piece: ',chessboard.board[from_x][from_y])
                    print('target_piece: ', chessboard.board[to_x][to_y])

                    if chessboard.is_move_legal(move,True) and chessboard.board[from_x][from_y][0] == 'w':

                        print('sssssssssssssssssssssssssssssssssssssssssss')

                        chessboard.make_move(move)  # Make the player's move
                        #chessboard_gui.selected_piece = None  # Reset selected_piece
                        #chessboard_gui.selected_position = None  # Reset selected_position
                        chessboard_gui.draw_board()  # Update the GUI
                        #player_turn = False  # Switch to AI's turn

                    else:
                        # Handle invalid moves here
                        print("Invalid move!...try again")
                        chessboard_gui.selected_piece = None  # Reset selected_piece
                        chessboard_gui.selected_position = None  # Reset selected_position
                else:
                    # Handle an unexpected format for selected_piece
                    print("Unexpected format for selected_piece or selected_position")
                    chessboard_gui.selected_piece = None  # Reset selected_piece
                    chessboard_gui.selected_position = None  # Reset selected_position


        elif chessboard_gui.selected_position is not None and chessboard_gui.selected_piece is not None:
            print('ai: ')
            chessboard_gui.selected_piece = None  # Reset selected_piece
            chessboard_gui.selected_position = None  # Reset selected_position
            # AI's turn
            chessboard_gui.ai_turn(player_turn)

        player_turn = not player_turn

    if chessboard.is_checkmate(player_turn):
        print('CHECKMATE')
    elif chessboard.is_stalemate(player_turn):
        print('STALEMATE')

    # Start the Tkinter main loop
    root.mainloop()



if __name__ == "__main__":
    main()

