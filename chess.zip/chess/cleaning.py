import gzip
import chess.pgn

gzipped_file_path = "lichess.gz"

processed_games = []

with gzip.open(gzipped_file_path, "rt", encoding="latin-1") as pgn_file:
    while True:
        try:

            game = chess.pgn.read_game(pgn_file)

            if game is None:
                break

            moves = list(game.mainline_moves())
            result = game.headers["Result"]
            event = game.headers["Event"]
            white_player = game.headers["White"]
            black_player = game.headers["Black"]
            date = game.headers["Date"]

            processed_game_data = {
                "moves": moves,
                "result": result,
                "event": event,
                "white_player": white_player,
                "black_player": black_player,
                "date": date
            }

            processed_games.append(processed_game_data)

        except ValueError as e:
            print(f"Skipping game due to error: {e}")
